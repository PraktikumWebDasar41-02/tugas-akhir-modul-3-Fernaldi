<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<FORM action="Hal1.php" method="POST">
		<input type="text" name="user" placeholder="Username"><br>
		<input type="password" name="pass" placeholder="Password"><br> 
		<input type="submit" name="submit" value="Login"><br><br><br>
		Belum Punya Akun&nbsp<a href="Hal2.php">Daftar</a>	
	</FORM>
</body>
</html>

<?php 

	session_start();
	include "Koneksi.php";
	if (isset($_POST['submit'])) {
		$username = $_POST['user'];
		$password = $_POST['pass'];
	

	$dt = mysqli_query($con, "SELECT * FROM `user` WHERE `Username`='$username' AND `Password`='$password'");
	$cek = mysqli_num_rows($dt);

		if($cek > 0){
			$_SESSION['user'] = $username;
			header("Location:Hal5.php");
		}
			else{
				echo "<script>alert('LOGIN FAILED')</script>";
			}
	}
 ?>