<!DOCTYPE html>
<html>
<head>
	<title>Create Account </title>
</head>
<body>
	<FORM action="#" method="POST">
		<input type="text" name="user" placeholder="Username" required><br>
		<input type="password" name="pass" placeholder="Password" required><br>
		<input type="password" name="repass" placeholder="Re-Password" required><br> 
		<input type="submit" name="signup" value="Signup">&nbsp&nbsp&nbsp&nbsp
		<a href="Hal1.php">Login</a>
	</FORM>
</body>
</html>



<?php 
	include("Koneksi.php");
		if (isset($_POST['signup'])) {
			$username = $_POST['user'];
			$password = $_POST['pass'];
			$repassword = $_POST['repass'];

			if ($password==$repassword) {
				$syntax = "INSERT INTO `user`(`Username`, `Password`) VALUES ('$username','$password')";
				if($con->query($syntax) === TRUE){
					echo"Successfully!";
				}else{
					echo"Failed".$con->error;
				}
			}else{
				echo"Wrong Password!!";
			}
		}

 ?>