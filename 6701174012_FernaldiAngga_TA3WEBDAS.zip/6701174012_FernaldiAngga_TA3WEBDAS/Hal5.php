<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="Hal5.php" method="post" enctype="multipart/form-data">
		
		<?php 
		session_start();
		echo $_SESSION['user'];
		?><br><br>

		Upload Gambar	<input type="file" name="gambar"><br>
		<input type="submit" name="submit" value="Upload">
	</form>
</body>
</html>

<?php 
include "Koneksi.php";
$user = $_SESSION['user'];
if (isset($_POST['submit'])) {
	$data = 'Picture/';
	$bag = $data.basename($_FILES['gambar']['name']);
	$syntax ="INSERT INTO `gambar`(`Username`, `KodeGambar`) VALUES ('$user', '$bag')";


	if ($con->query($syntax) === TRUE) {
		echo "<br>UPLOAD BERHASIL";
	}else{
		echo "<br>UPLOAD GAGAL" . $con->error;
	}
}

 ?>

 <h1>FOTO</h1>
 <table border="1">
 	<?php 
	include"Koneksi.php";
	$syntax = mysqli_query($con, "SELECT * FROM `gambar` WHERE `Username` = '$user'");
	$no=1;
		 echo "<img src ='$bag' width='300' height='300'>";
		 while ($hasil=mysqli_fetch_array($syntax)){
           echo "<img src ='".$hasil['KodeGambar']."' width='200' weight='200'>";
           $no++;      }
 	 ?>

 </table>