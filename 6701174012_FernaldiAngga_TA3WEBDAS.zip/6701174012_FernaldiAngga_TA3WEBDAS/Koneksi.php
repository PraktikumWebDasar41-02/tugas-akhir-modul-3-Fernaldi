<?php 

$server = "localhost";
$user = "root";
$pass = "";
$db = "TA2";
	$con = mysqli_connect($server, $user, $pass, $db);


	if($con->connect_error){
		die ("Connection Failed". $con->connect_error);
	}
?>