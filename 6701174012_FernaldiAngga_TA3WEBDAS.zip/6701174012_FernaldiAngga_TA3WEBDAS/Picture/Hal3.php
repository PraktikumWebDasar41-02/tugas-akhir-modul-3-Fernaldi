<!DOCTYPE html>
    <title></title>
  </head>
  <body>
    <form action="Hal3.php" method="post" enctype="multipart/form-data">

    <?php
    session_start(); echo $_SESSION['username']; ?>
    <input type="submit" name="keluar" value="LogOut">
    <br>
    Upload Foto<input type="file" name="foto">
    <br>
    <input type="submit" name="submit" value="Upload">

  </form>
  </body>
</html>

<?php
include "koneksinya.php";
$user =  $_SESSION['username'];
if (isset($_POST['submit'])) {
  $file = 'ASISTEN/';

  $path = $file.basename($_FILES['foto']['name']);
  $sql = "INSERT INTO `gambar` (`username`, `foto`) VALUES ('$user', '$path');";

  if ($conn->query($sql) === TRUE) {
      echo "<br>UPLOAD BERHASIL";
  } else {
      echo "<br>UPLOAD ERROR: " . $conn->error;
  }

}
?>
<!-- echo "<br><img src='$path' height='240' width='240'>"; -->
<h2>List Foto</h2>
<table border="0">
    <?php
    include 'koneksinya.php';
    $sql = mysqli_query($conn, "SELECT * from gambar WHERE username = '$user'");
    $no=1;
            foreach ($sql as $row){
          echo "  <td>
          <a href='4.php?id=".$row['id']."'><img src='".$row['foto']."' width='200' weight='200'></a>
          </td>";
          $no++;
          if ($no>3) {
            echo "<tr></tr>";
            $no = 1;
          }
      }
    ?>
</table>
<?php
if (isset($_POST['keluar'])) {
 session_destroy();
 $conn->close();
 header("Location:1.php");
}
 ?>

