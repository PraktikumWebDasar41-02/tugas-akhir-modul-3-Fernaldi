<?php
session_start();
error_reporting(0);
        $user = array(
                "user" => "fernaldiangga",
                "password"=>6701174012            
                );
if (isset($_POST['submit'])) {
    if ($_POST['us'] == $user['user'] && $_POST['pass'] == $user['password']){
        $_SESSION["us"] = $_POST['us']; 
        echo "Login berhasil <b>$_POST[us]</b>" ;
    } else {
        login();
        echo '<p>Username Atau Password Tidak Benar</p>';
    }
}    
else { 
    	login();
}
function login(){ ?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method='post'>
    Username <input type="text" name="us"><br><br>
    Password <input type="password" name="pass"><br><br>
    <input type="submit" name="submit" value="Submit">
    </form>    
<?php } ?>